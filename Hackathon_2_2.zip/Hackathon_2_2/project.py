import sys
class AdvancedAlchemyGame:
    def __init__(self):
        # All possible basic elements
        self.all_elements = ["water", "earth", "fire", "air"]
        
        # Reactions
        raw_reactions = {
            ("water", "earth"): "mud",
            ("fire", "earth"): "lava",
            ("water", "air"): "cloud",
            ("fire", "air"): "energy",
            ("mud", "fire"): "brick",
            ("brick", "brick"): "house",
            ("water", "energy"): "electricity",
            ("electricity", "cloud"): "storm"
        }
        self.reactions = {tuple(sorted(k)): v for k, v in raw_reactions.items()}

        self.history = []
        self.achievements = {
            "first_combo": False,
            "five_discoveries": False,
            "made_house": False
        }

        # Start with only two unlocked elements (to prevent early triggering)
        self.unlocked_elements = set(["water", "fire"])

    

    def combine(self, e1, e2):
        result = self.reactions.get(tuple(sorted((e1, e2))))
        if result:
            print(f"\n✨ SUCCESS! {e1.capitalize()} + {e2.capitalize()} = {result.capitalize()} ✨\n")
            self.history.append(f"{e1} + {e2} → {result}")
            self.unlocked_elements.add(result)

            if not self.achievements["first_combo"]:
                self.achievements["first_combo"] = True
                print("🏆 Achievement Unlocked: First Discovery!")

            if len(self.unlocked_elements) >= 5 and not self.achievements["five_discoveries"]:
                self.achievements["five_discoveries"] = True
                print("🏆 Achievement Unlocked: 5 Discoveries!")

            if result == "house" and not self.achievements["made_house"]:
                self.achievements["made_house"] = True
                print("🏡 Achievement Unlocked: You built a house!")
        else:
            print("\n❌ Nothing happened. Try different elements.\n")

    def show_hint(self):
        print("\n💡 Hint: Try combining elements you've recently discovered!\n")

    def command_mode(self, cmd):
        if cmd == "elements":
            print("\n🧪 Discovered Elements:", ", ".join(sorted(self.unlocked_elements)))
        elif cmd == "history":
            self.show_history()
        elif cmd == "achievements":
            print("\n🏅 Achievements Status:")
            for k, v in self.achievements.items():
                status = "✅" if v else "❌"
                print(f" - {k.replace('_', ' ').title()}: {status}")
        elif cmd == "help":
            print("\n💡 Commands: 'elements', 'history', 'achievements', 'hint', 'exit'\n")
        else:
            print("\n❓ Unknown command. Try 'help'.\n")

    def show_history(self):
        print("\n📜 Combination History:")
        for h in self.history:
            print(" -", h)

    def start(self):
        print("🎮 Welcome to the Advanced Alchemy Game!")
        print("💬 Combine elements to create new ones!")
        print("📘 Type commands like 'help', 'elements', or 'exit' anytime.\n")
        
        while True:
            e1 = input("🔹 Enter first element (or command): ").strip().lower()

            if e1 in ["exit", "hint", "elements", "history", "achievements", "help"]:
                if e1 == "exit":
                    sys.exit("👋 Game exited.")
                elif e1 == "hint":
                    self.show_hint()
                else:
                    self.command_mode(e1)
                continue

            e2 = input("🔸 Enter second element: ").strip().lower()
            self.combine(e1, e2)

if __name__ == "__main__":
    game = AdvancedAlchemyGame()
    game.start()
